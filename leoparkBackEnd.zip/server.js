const express = require('express');
const bodyParser = require('body-parser');
const server = express();
const MongoClient = require('mongodb').MongoClient;

server.use(bodyParser.urlencoded({extended: true}))
server.use(bodyParser.json());

const urlBD = 'mongodb://userleopark:userleopark@ds121898.mlab.com:21898/pruebaleopark';
var bd;

MongoClient.connect(urlBD, (err, database) => {
	
	if(err) return console.log(err);
	
		// Inicio del servidor
	db = database.db('pruebaleopark');
	server.listen(3000, () => {
		console.log("Listening in port 3000");
	});
});

server.get('/', (req, res) => {
	res.sendFile(__dirname + "/index.html");
});

// Prime Reto
server.post('/primerBackend', (req, res)=>{
	console.log(req.body);

	var posAleatorias = [];
	var tam=0;
	var x = req.body.valueX;
	var y = req.body.valueY;

	// Verificando que los campos sean validos
	if(isNaN(x)) res.send("x no es un número");
	else if(isNaN(y)) res.send("y no es un número");
	else if(x < 0 || x > 1) res.send("x no es un número valido (fuera de rango)");
	else if(y <= 0 || y > 1) res.send("y no es un número valido (fuera de rango)");
	else if(parseFloat(x) + parseFloat(y) > 1.0) res.send("(x,y) fuera de rango");
	else {

		// Hacemos cast a float a (X,Y), para evitar problemas
		// con los decimales multiplicamos por 10
		x = parseFloat(x)*10; // Cast to float
		y = parseFloat(y)*10;
		tam = y;

		for(i = 0.0; i <= x-tam; i++){
			posAleatorias.push(i/10);
		}

		for(i = x+y; i <= 10.0-tam; i++){
			posAleatorias.push(i/10);
		}

		if(posAleatorias.length){
			var random = Math.floor(Math.random() * (posAleatorias.length));
			console.log(posAleatorias);

			var newPunto = {
				x : posAleatorias[random],
				y : y
			};

			// Almacenando punto en la BD
			db.collection('puntos').save(newPunto, (err, result) => {
				if(err) return console.log(err);
				console.log('guardado en bd');
			});

			res.send(newPunto);
		}
		else {
			res.send(false);
		}
	}
});

// Segundo Reto
server.post('/segundoBackend', (req, res) => {
	console.log('Se recibio post');
	console.log(req.body);
	var x = req.body.valueX;
	var y = req.body.valueY;
	var z = req.body.valueZ;
	var randX = 0.0;
	var randY = 0.0;
	var yArray = [];

	// Regresa 0 si los campos son validos, caso contrario regresa numero de error
	var error = validarCampos(x,y,z);
	if(error == 0){

		// Trabajando con numeros naturales para evitar problemas
		x = parseFloat(x)*10.0;
		y = parseFloat(y)*10.0;
		z = parseFloat(z)*10.0;

		// Obtengo nuevo valor de x entre [0...10]
		randX = Math.floor(Math.random() * (11-z) + 0);

		// Filtro valores que puede obtener Y para que no traslape con el punto dado 
		if((randX > x-z) && (randX < x+z)){ // Si hay traslape filtro
			for(i = 0.0; i <= y-z; i++){
				yArray.push(i/10.0);
			}

			for(i = y+z; i <= 10.0-z; i++){
				yArray.push(i/10.0);
			}
		}
		else { // Si no obtengo todos los posibles valores para Y
			for(i = 0.0; i <= 10.0-z; i++){
				yArray.push(i/10.0);
			}
		}

		// Regresa error -12 si no se pudo obtener nuevo cuadrado en el plano
		if(yArray.length == 0){
			res.send({error: -12});
			return 0;
		}

		// Obtengo nuevo valor de Y
		randY = yArray[Math.floor(Math.random() * (yArray.length))];

		var newCuadrado = {
			x: randX / 10.0,
			y: randY / 1.0,
			z: z / 10.0,
		};

		// Almacena el nuevo cuadrado en la BD
		db.collection('cuadrados').save(newCuadrado, (err, result) => {
				if(err) return console.log(err);
				console.log('guardado en bd');
		});

		// Regreso el nuevo cuadrado
		res.send(newCuadrado);
		return 1;
	}
	else{
		res.send({error});
		return 0;
	}
});

// Verifica que los campos sean validos y se puedan obtener nuevos valores
function validarCampos(x, y, z){
	
	if(isNaN(x)) return -1; // X no es numero
	else if(isNaN(y)) return -2; // Y no es numero
	else if(isNaN(z)) return -3; // Z no es numero
	else if(x < 0.0 || x > 1.0) return -4; // X es menor que 0 o mayor que 1
	else if(y < 0.0 || y > 1.0) return -5; // Y es menor que 0 o mayor que 1
	else if(z <= 0.0 || z > 1.0) return -6; // Z es menor o igual que 0 o mayor que 1
	else if((x+y) > 1.0) return -7; // X + Y es mayor que 1
	else if((x+z) > 1.0) return -8; // X + Z es mayor que 1
	else if((y+z) > 1.0) return -9; // Y + Z es mayor que 1
	else if((x+y) > 0.5) return -10; // No se puede dar nuevo punto
	else if((x+z) > 0.5) return -11; // No se puede dar nuevo cuadrado
	else return 0;
}