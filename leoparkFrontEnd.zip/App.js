import React, { Component } from 'react';
import { AppRegistry, StyleSheet, Image, Text, TextInput, View, Alert, Button } from 'react-native';

export default class App extends Component {
	constructor (props){
		super(props);
		this.state = {
			server: '192.168.15.10',
			port: '3000',
			tablero: <View/>
		};

	}


	render(){

		return (
			<View style = {{flex: 1}}>
				<View style = {{flex : 2, flexDirection:'column', backgroundColor: 'powderblue', justifyContent: 'center', alignItems: 'center'}}>
						<View style = {{flex : 1, flexDirection: 'row', padding: 30}}>
							<TextInput 
								placeholder = 'Server: '
								placeholderTextColor = 'gray'
								style = {{fontSize: 20, width: 350, height: 40, borderColor: 'gray'}}
								onChangeText = {(server) => this.setState({server})}
							/>

							<TextInput
								keyboardType = 'numeric'
								placeholder = 'Port: (default 3000)'
								placeholderTextColor = 'gray'
								style = {{fontSize: 20, width: 50, height: 40, borderColor: 'gray'}}
								onChangeText = {(port) => this.setState({port})}
							/>
						</View>

						<View style = {{flex : 1, flexDirection: 'row'}}>
							<TextInput
								keyboardType = 'numeric'
								placeholder = 'valor x'
								placeholderTextColor = 'gray'
								style = {{fontSize: 20, width: 80, height: 25}}
								onChangeText = {(x) => this.setState({x})}
							/>

							<TextInput
								keyboardType = 'numeric'
								placeholder = 'valor y'
								placeholderTextColor = 'gray'
								style = {{fontSize: 20, width: 80, height: 25}}
								onChangeText = {(y) => this.setState({y})}
							/>

							<TextInput
								keyboardType = 'numeric'
								placeholder = 'valor z'
								placeholderTextColor = 'gray'
								style = {{fontSize: 20, width: 80, height: 25}}
								onChangeText = {(z) => this.setState({z})}
							/>

							<Button
								title = 'Enviar'
								onPress = { () => {
									newFigura(
										this.state.server,
										this.state.port,
										this.state.x,
										this.state.y,
										this.state.z,
										this
									);
								}}
							/>
						</View>

				</View>

				<View style = {{flex:10}}>
					{this.state.tablero}
				</View>
			</View>
		);
	}
}

function newFigura(server, port, x, y, z, app){
	
	// Conectando al servidor
	fetch('http://' + server + ':' + port + '/segundoBackend', {
	  	method: 'POST',
	  	headers: {
	    	Accept: 'application/json',
	    	'Content-Type': 'application/json',
	  	},

	  	body: JSON.stringify({
	    	valueX: x,
	    	valueY: y,
	    	valueZ: z,
	  	})
	})
	.then((res) => { return res.json()})
		.then((data) => { 
			//var fig = JSON.stringify(data);
			var msg = " ";

			// Si hubo un error en los campos 
			if(data.error < 0){
				//Alert.alert(data.error);
				switch(data.error){
					case -1: msg = "Error: X no es numero";
						break;
					case -2: msg = "Error: Y no es numero";
						break;
					case -3: msg = "Error: Z no es numero";
						break;
					case -4: msg = "Error: X es menor que 0 o mayor que 1";
						break;
					case -5: msg = "Error: Y es menor que 0 o mayor que 1";
						break;
					case -6: msg = "Error: Z es menor o igual que 0 o mayor que 1";
						break;
					case -7: msg = "Error: X + Y es mayor que 1";
						break;
					case -8: msg = "Error: X + Z es mayor que 1";
						break;
					case -9: msg = "Error: Y + Z es mayor que 1";
						break;
					case -10: msg = "Error: X no es numero";
						break;
					case -11: msg = "Error: No se puede dar nuevo punto";
						break;
					case -12: msg = "Error: No hay espacio para nueva figura";
						break;
				}
			}
			// Si no hubo problemas en obtener los datos
			else {
				msg = 'Nueva figura: ' + JSON.stringify(data);

				var X = x*10;
				var Y = y*10;
				var Z = z*10;

				// Creando matriz colores
				var m = [];
				var r = [];
				for(i = 0; i < 10; i++){	
					r = [];
					for(j = 0; j < 10; j++){
						r.push(0);
					}
					m.push(r);
				}

				// Agregando primer cuadrado
				for(i = Y; i < (Y+Z); i++){
					for(j = X; j < (X+Z); j++){
						m[i][j] = 1;
					}
				}

				// Agregando segundo cuadrado
				dataY = data.y * 10;
				dataX = data.x * 10;
				dataZ = data.z * 10;

				for(i = dataY; i < (dataY+dataZ); i++){
					for(j = dataX; j < (dataX+dataZ); j++){
						m[i][j] = 1;
					}
				}

				// Creando tablero
				let posiciones = [
					{key: 0},
					{key: 1},
					{key: 2},
					{key: 3},
					{key: 4},
					{key: 5},
					{key: 6},
					{key: 7},
					{key: 8},
					{key: 9},
				];

				var ren = 0;
				var col = 0;
				var tablero = posiciones.map(k => {
					return (
						<View key = {k.key} style = {{flex:1, flexDirection: 'row'}}>
							{
								posiciones.map(k2 => {
									return(
										<View key = {k2.key} style ={{flex: 1, backgroundColor: m[k.key][k2.key]==0 ? 'skyblue': 'steelblue' ,borderWidth : 1}}/>
									);
								})
							}
						</View>
					);
				});


				app.setState(previousState => {
					return {tablero: tablero}
				});
			}

			Alert.alert(msg);
		});

	return true;
}

// skip this line if using Create React Native App
AppRegistry.registerComponent('AwesomeProject', () => App);